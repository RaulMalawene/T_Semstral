
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import javax.swing.JOptionPane;

public class Randomtest {
    
    public static void main(String[] args){
        
     ArrayList<String>list = new ArrayList();
  //   ArrayPuxar ap = new ArrayPuxar("ola");
     
  //  list.add(ap.toString());
    
    }
}
