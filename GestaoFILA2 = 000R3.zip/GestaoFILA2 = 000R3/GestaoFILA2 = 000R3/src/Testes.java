
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Testes {
    
   public static void main(String[] args){

   Randomtest rt = new Randomtest();
   
       
    } 
}
